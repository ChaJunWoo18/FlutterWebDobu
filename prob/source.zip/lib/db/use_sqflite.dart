import 'sqflite_control.dart';
import 'sqflite_model.dart';

class UseSqflite {
  late SqfliteControl sqfliteControl;

  Future<void> insertTestData() async {
    SqfliteModel testData1 = SqfliteModel(
      date: '2023-07-15',
      receiver: 'Alice',
      amount: 100,
      category: "cafe",
    );

    SqfliteModel testData2 = SqfliteModel(
      date: '2023-07-16',
      receiver: 'Bob',
      amount: 150,
      category: "food",
    );

    SqfliteModel testData3 = SqfliteModel(
      date: '2023-07-16',
      receiver: 'Ewwq',
      amount: 350,
      category: "cafe",
    );

    await SqfliteControl.insertQuery(testData1);
    await SqfliteControl.insertQuery(testData2);
    await SqfliteControl.insertQuery(testData3);
  }

  Future<List<SqfliteModel>> getAllData() async {
    return await SqfliteControl.getAllConsumHis();
  }
}
