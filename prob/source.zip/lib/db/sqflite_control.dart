import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';
import 'sqflite_model.dart';

class SqfliteControl {
  static late Database database;
  static late String _path;

  static Future<String> createDB() async {
    var databasesPath = await getDatabasesPath();
    _path = join(databasesPath, 'history.db');
    return _path;
  }

  static Future<void> createTable() async {
    database = await openDatabase(
      _path,
      version: 1,
      onCreate: (db, version) async {
        await db.execute(
          '''CREATE TABLE consum_his (id INTEGER PRIMARY KEY AUTOINCREMENT, 
                                      date TEXT NOT NULL, 
                                      receiver TEXT NOT NULL, 
                                      amount INTEGER NOT NULL,
                                      category TEXT NOT NULL)
          ''',
        );
      },
    );
  }

  static Future<void> initializeDatabase() async {
    await createDB();
    await createTable();
  }

  static Future insertQuery(SqfliteModel sqfliteModel) async {
    await database.insert(
      'consum_his',
      sqfliteModel.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // 데이터 수정
  static Future<void> updateConsumHis(SqfliteModel sqfliteModel) async {
    await database.update(
      'consum_his',
      sqfliteModel.toMap(),
      where: 'id = ?',
      whereArgs: [sqfliteModel.id],
    );
  }

  // 데이터 삭제
  static Future<void> deleteConsumHis(SqfliteModel sqfliteModel) async {
    await database.delete(
      'consum_his',
      where: 'id = ?',
      whereArgs: [sqfliteModel.id],
    );
  }

  // 데이터 전부 삭제
  static Future<void> deleteAllConsumHis() async {
    await database.delete('consum_his');
  }

  static Future<List<SqfliteModel>> getAllConsumHis() async {
    final List<Map<String, dynamic>> maps = await database.query('consum_his');

    return List.generate(maps.length, (i) {
      return SqfliteModel(
        id: maps[i]['id'],
        date: maps[i]['date'],
        receiver: maps[i]['receiver'],
        amount: maps[i]['amount'],
        category: maps[i]['category'],
      );
    });
  }
}
