class SqfliteModel {
  late int? id;
  late final String date;
  late final String receiver;
  late final int amount;
  late final String category;

  SqfliteModel({
    this.id,
    required this.date,
    required this.receiver,
    required this.amount,
    required this.category,
  });

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'date': date,
      'receiver': receiver,
      'amount': amount,
      'category': category,
    };
  }

  factory SqfliteModel.fromMap(Map<String, dynamic> map) {
    return SqfliteModel(
      id: map['id'],
      date: map['date'],
      receiver: map['receiver'],
      amount: map['amount'],
      category: map['category'],
    );
  }
}
